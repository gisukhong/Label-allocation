# Prediction based manufacturing inspection

Core implementation of the controlled comparison protocol in *Separating Quality Reference and Label Allocation Effects in Prediction-Based Manufacturing Inspection*.

## Contents

- `protocol.py`: model fitting, label allocation, residual calibration, policy selection, reference assessment, and matched-burden comparison.
- `run_analysis.py`: the LPBF comparison workflow using externally supplied processed observations.
- `requirements.txt`: recorded dependency versions.

## Run

Use Python 3.12. Supply a processed CSV and a JSON array containing the ordered predictor column names.

```bash
python -m pip install -r requirements.txt
python run_analysis.py --data /path/to/patches.csv --features /path/to/features.json --output results
```

## Input contract

Each CSV row represents one retained patch. Preserve the original patch order to reproduce the seeded label allocations.

| Required column | Meaning |
|---|---|
| `part` | Integer part identifier, 1 through 4 |
| `ix` | Integer patch-grid column index |
| `q_um` | Nominal intrusion reference in micrometers |
| `q_low_um` | Lower reference endpoint in micrometers |
| `q_high_um` | Upper reference endpoint in micrometers |
| Predictor columns | Finite numeric features listed in the supplied JSON file |

The predictor list must exclude the identifiers and reference columns. The manuscript specifies 41 features. Their definitions, reference processing, and patch inclusion rules are given in the manuscript and supplementary methods. Reference bounds must contain the nominal reference. Extra CSV columns are ignored unless selected as predictors.

The runner retains the paper's cyclic source/target pairs, primary and shifted grid-column splits, seeds 17/43/71, 400 micrometer analysis tolerance, and fixed random-forest settings. Each part and split needs at least 64 pool rows and a nonempty testing subset. A different application requires corresponding changes to these case settings.

## Outputs and interpretation

The workflow writes five CSV files: unchanged-set reassessment, calibration comparisons, paired label allocations, validation-gate candidates, and an additive matched-burden control. It holds predictions fixed within each reference contrast and within the 24/16/24 versus 24/24/16 allocation pair.

The validation gate uses observed acceptance counts and exceedance fractions. It does not establish a finite-sample guarantee for testing outcomes. Matched burden uses testing counts retrospectively.

## Scope and data source

No observations, feature-list file, recorded results, trained models, or synthetic data are bundled. Running the workflow requires the corresponding processed inputs. This is a source-only implementation of the principal comparisons, not a complete paper-reproduction package. It excludes raw XCT extraction, exhaustive sensitivity grids, repeated role-order experiments, and publication figure generation.

The public source dataset is available at https://doi.org/10.18434/mds2-3761. Original process and XCT releases are https://doi.org/10.18434/mds2-2233 and https://doi.org/10.18434/mds2-2291. These releases are source observations, not the ready-to-run processed CSV required here.
