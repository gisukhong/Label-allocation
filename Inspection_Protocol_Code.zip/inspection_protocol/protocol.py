import math

import numpy as np
from sklearn.ensemble import RandomForestRegressor


def fit_predict(frame, train, features):
    model = RandomForestRegressor(
        n_estimators=160, min_samples_leaf=5, max_features=0.8,
        random_state=31, n_jobs=2
    )
    model.fit(frame.loc[train, features].to_numpy(), frame.loc[train, 'q_um'].to_numpy())
    return np.maximum(0.0, model.predict(frame[features].to_numpy()))


def target_split(frame, part, split, seed):
    pool_residue, test_residue = {'primary': (0, 2), 'shifted': (1, 3)}[split]
    pool = frame.index[(frame.part == part) & (frame.ix % 4 == pool_residue)].to_numpy()
    test = frame.index[(frame.part == part) & (frame.ix % 4 == test_residue)].to_numpy()
    return pool[np.random.default_rng(seed).permutation(len(pool))], test


def allocate(order, f, c, v):
    if min(f, c, v) < 0 or f + c + v > len(order):
        raise ValueError('Invalid role allocation')
    return order[:f], order[f:f+c], order[f+c:f+c+v]


def calibration_radius(prediction, lower, upper, level=0.90, score='upper'):
    if not 0 < level < 1 or score not in ('upper', 'symmetric'):
        raise ValueError('Invalid calibration specification')
    n = len(prediction)
    rank = math.ceil((n + 1) * level)
    if rank > n or n == 0:
        return np.inf
    residual = np.asarray(upper) - np.asarray(prediction)
    if score == 'symmetric':
        residual = np.maximum(residual, np.asarray(prediction) - np.asarray(lower))
    return max(0.0, float(np.partition(residual, rank - 1)[rank - 1]))


def select_policy(prediction, upper, radius, tolerance=400.0,
                  multipliers=(1.0, 1.5, 2.0, 3.0), minimum=10, limit=0.05):
    if minimum < 1 or not 0 <= limit <= 1 or any(m <= 0 for m in multipliers):
        raise ValueError('Invalid policy gate')
    candidates = []
    for multiplier in multipliers:
        accepted = np.asarray(prediction) + multiplier * radius <= tolerance
        count = int(accepted.sum())
        exceedances = int((accepted & (np.asarray(upper) > tolerance)).sum())
        candidates.append(dict(multiplier=float(multiplier), accepted=count,
                               exceedances=exceedances,
                               eligible=count >= minimum and exceedances <= limit * count))
    eligible = [row for row in candidates if row['eligible']]
    chosen = min(eligible, key=lambda row: (-row['accepted'], row['multiplier'])) if eligible else None
    return (None if chosen is None else chosen['multiplier']), candidates


def decide(prediction, radius, multiplier, tolerance=400.0):
    if multiplier is None:
        return np.zeros(len(prediction), dtype=bool)
    if multiplier <= 0:
        raise ValueError('Multiplier must be positive')
    return np.asarray(prediction) + multiplier * radius <= tolerance


def assess(accepted, reference, tolerance=400.0):
    accepted = np.asarray(accepted, dtype=bool)
    count = int(accepted.sum())
    exceedances = int((accepted & (np.asarray(reference) > tolerance)).sum())
    return dict(accepted=count, exceedances=exceedances,
                fraction=exceedances / count if count else None)


def common_margin(predictions, radii, target_count, tolerance=400.0, step=0.01):
    ceiling = max(0.0, max((tolerance - np.asarray(p) - r).max()
                           for p, r in zip(predictions, radii)))
    margins = np.arange(math.ceil(ceiling / step) + 2) * step
    counts = np.zeros(len(margins), dtype=int)
    for prediction, radius in zip(predictions, radii):
        thresholds = np.sort(tolerance - np.asarray(prediction) - radius)
        counts += len(thresholds) - np.searchsorted(thresholds, margins, side='left')
    best = int(np.argmin(np.abs(counts - target_count)))
    return float(margins[best]), int(counts[best])
