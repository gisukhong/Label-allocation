from pathlib import Path
import argparse
import json

import numpy as np
import pandas as pd

from protocol import (
    allocate, assess, calibration_radius, common_margin, decide,
    fit_predict, select_policy, target_split
)


def run(data, feature_file, output):
    frame = pd.read_csv(data, float_precision='round_trip').reset_index(drop=True)
    features = json.loads(feature_file.read_text())
    required = {'part', 'ix', 'q_um', 'q_low_um', 'q_high_um'}
    if not isinstance(features, list) or not features or not all(isinstance(x, str) for x in features):
        raise ValueError('Features must be a nonempty JSON list of column names')
    if len(set(features)) != len(features) or required.intersection(features):
        raise ValueError('Features must be unique and exclude identifiers and references')
    if not required.union(features).issubset(frame.columns):
        raise ValueError('Input CSV is missing required columns or features')
    if not np.isfinite(frame[list(required) + features].to_numpy(dtype=float)).all():
        raise ValueError('Input values must be finite numeric values')
    if set(frame.part.unique()) != {1, 2, 3, 4}:
        raise ValueError('The LPBF runner requires part identifiers 1, 2, 3, and 4')
    if not (frame.ix == np.floor(frame.ix)).all():
        raise ValueError('Grid-column indices must be integers')
    if not ((frame.q_low_um <= frame.q_um) & (frame.q_um <= frame.q_high_um)).all():
        raise ValueError('Reference bounds must contain the nominal reference')
    for part in range(1, 5):
        for split in ('primary', 'shifted'):
            order, test = target_split(frame, part, split, 17)
            if len(order) < 64 or len(test) == 0:
                raise ValueError('Each part and split requires at least 64 pool rows and a nonempty test set')
    output.mkdir(parents=True, exist_ok=True)
    fixed, comparisons, allocations, candidates, controls = [], [], [], [], []
    case_predictions = {}
    for source_part, target_part in [(1, 4), (2, 1), (3, 2), (4, 3)]:
        source = frame.index[frame.part == source_part].to_numpy()
        target = frame.index[frame.part == target_part].to_numpy()
        prediction = fit_predict(frame, source, features)
        accepted = prediction[target] <= 400
        for reference, column in [('lower', 'q_low_um'), ('nominal', 'q_um'), ('upper', 'q_high_um')]:
            fixed.append(dict(part=target_part, reference=reference,
                              **assess(accepted, frame.loc[target, column])))
        for split in ['primary', 'shifted']:
            for seed in [17, 43, 71]:
                order, test = target_split(frame, target_part, split, seed)
                fit, cal, _ = allocate(order, 32, 32, 0)
                pred = fit_predict(frame, np.r_[source, fit], features)
                for score in ['upper', 'symmetric']:
                    masks, radii = {}, {}
                    for reference in ['nominal', 'expanded']:
                        low, high = ('q_um', 'q_um') if reference == 'nominal' else ('q_low_um', 'q_high_um')
                        radius = calibration_radius(pred[cal], frame.loc[cal, low], frame.loc[cal, high], score=score)
                        accepted = decide(pred[test], radius, 1.0)
                        masks[reference], radii[reference] = accepted, radius
                        comparisons.append(dict(split=split, part=target_part, seed=seed,
                            score=score, reference=reference, radius=radius,
                            **assess(accepted, frame.loc[test, 'q_high_um'])))
                    if np.any(masks['expanded'] & ~masks['nominal']):
                        raise RuntimeError('Fixed-prediction reference nesting failed')
                    case_predictions.setdefault((split, score), []).append(
                        (pred[test], radii['nominal'], frame.loc[test, 'q_high_um'].to_numpy(), int(masks['expanded'].sum())))
                fit, _, _ = allocate(order, 24, 16, 24)
                pred = fit_predict(frame, np.r_[source, fit], features)
                for c, v in [(16, 24), (24, 16)]:
                    _, cal, val = allocate(order, 24, c, v)
                    radius = calibration_radius(pred[cal], frame.loc[cal, 'q_low_um'], frame.loc[cal, 'q_high_um'])
                    multiplier, rows = select_policy(pred[val], frame.loc[val, 'q_high_um'], radius)
                    key = dict(split=split, part=target_part, seed=seed, fitting=24, calibration=c, validation=v)
                    candidates.extend([{**key, **row} for row in rows])
                    allocations.append({**key, 'radius': radius, 'multiplier': multiplier,
                        'enabled': multiplier is not None,
                        **assess(decide(pred[test], radius, multiplier), frame.loc[test, 'q_high_um'])})
    for (split, score), rows in case_predictions.items():
        target_count = sum(row[3] for row in rows)
        margin, count = common_margin([r[0] for r in rows], [r[1] for r in rows], target_count)
        bad = sum(assess(decide(pred, radius + margin, 1.0), upper)['exceedances']
                  for pred, radius, upper, _ in rows)
        controls.append(dict(split=split, score=score, added_margin=margin,
                             expanded_accepted=target_count, accepted=count, exceedances=bad))
    for name, records in [('reassessment', fixed), ('calibration', comparisons),
                          ('allocation', allocations), ('gate_candidates', candidates),
                          ('matched_burden', controls)]:
        pd.DataFrame(records).to_csv(output / f'{name}.csv', index=False)
    fixed_summary = pd.DataFrame(fixed).groupby('reference')[['accepted', 'exceedances']].sum()
    allocation_summary = pd.DataFrame(allocations).groupby(['split', 'calibration', 'validation'])[
        ['enabled', 'accepted', 'exceedances']].sum()
    print('Unchanged accepted population')
    print(fixed_summary.to_string())
    print('\nFixed-fitting allocation comparison')
    print(allocation_summary.to_string())
    print(f'\nResults written to {output.resolve()}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', type=Path, required=True)
    parser.add_argument('--features', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=Path('results'))
    args = parser.parse_args()
    run(args.data, args.features, args.output)
